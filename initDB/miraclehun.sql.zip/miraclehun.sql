-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: db4free.net:3306
-- Generation Time: May 31, 2012 at 01:54 PM
-- Server version: 5.6.5-m8-log
-- PHP Version: 5.3.10-1ubuntu3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `miraclehun`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--
-- Creation: May 31, 2012 at 09:38 AM
-- Last update: May 31, 2012 at 10:23 AM
--

DROP TABLE IF EXISTS `administrators`;
CREATE TABLE IF NOT EXISTS `administrators` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`id`, `user`, `password`) VALUES(1, 'azur3', 'Corr1dor');

-- --------------------------------------------------------

--
-- Table structure for table `altchars`
--
-- Creation: May 31, 2012 at 09:16 AM
-- Last update: May 31, 2012 at 09:16 AM
--

DROP TABLE IF EXISTS `altchars`;
CREATE TABLE IF NOT EXISTS `altchars` (
  `alt_id` int(5) NOT NULL AUTO_INCREMENT,
  `main_id` int(5) NOT NULL,
  PRIMARY KEY (`alt_id`),
  UNIQUE KEY `alt_id` (`alt_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `characters`
--
-- Creation: May 31, 2012 at 09:14 AM
-- Last update: May 31, 2012 at 09:14 AM
--

DROP TABLE IF EXISTS `characters`;
CREATE TABLE IF NOT EXISTS `characters` (
  `keycode` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `class` tinyint(2) NOT NULL,
  `is_main` tinyint(1) DEFAULT NULL,
  `role_main` tinyint(1) NOT NULL,
  `role_alt` tinyint(1) NOT NULL,
  `profession_main` tinyint(2) NOT NULL,
  `profession_alt` tinyint(2) NOT NULL,
  `rank` varchar(12) NOT NULL,
  `join_date` date NOT NULL,
  PRIMARY KEY (`keycode`),
  UNIQUE KEY `keycode` (`keycode`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--
-- Creation: May 31, 2012 at 10:42 AM
-- Last update: May 31, 2012 at 10:50 AM
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `class` varchar(16) NOT NULL,
  PRIMARY KEY (`class_id`),
  UNIQUE KEY `class_id` (`class_id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class`) VALUES(1, 'DeathKnight');
INSERT INTO `classes` (`class_id`, `class`) VALUES(2, 'Druid');
INSERT INTO `classes` (`class_id`, `class`) VALUES(3, 'Hunter');
INSERT INTO `classes` (`class_id`, `class`) VALUES(4, 'Mage');
INSERT INTO `classes` (`class_id`, `class`) VALUES(5, 'Paladin');
INSERT INTO `classes` (`class_id`, `class`) VALUES(6, 'Priest');
INSERT INTO `classes` (`class_id`, `class`) VALUES(7, 'Rogue');
INSERT INTO `classes` (`class_id`, `class`) VALUES(8, 'Shaman');
INSERT INTO `classes` (`class_id`, `class`) VALUES(9, 'Warlock');
INSERT INTO `classes` (`class_id`, `class`) VALUES(10, 'Warrior');

-- --------------------------------------------------------

--
-- Table structure for table `dkp`
--
-- Creation: May 31, 2012 at 09:15 AM
-- Last update: May 31, 2012 at 09:15 AM
--

DROP TABLE IF EXISTS `dkp`;
CREATE TABLE IF NOT EXISTS `dkp` (
  `dkp_id` int(5) NOT NULL AUTO_INCREMENT,
  `keycode` int(5) NOT NULL,
  `points` int(7) NOT NULL,
  PRIMARY KEY (`dkp_id`),
  UNIQUE KEY `dkp_id_keycode` (`dkp_id`,`keycode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infos`
--
-- Creation: May 31, 2012 at 09:49 AM
-- Last update: May 31, 2012 at 09:49 AM
--

DROP TABLE IF EXISTS `infos`;
CREATE TABLE IF NOT EXISTS `infos` (
  `info_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(16) NOT NULL,
  `date` datetime NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`info_id`),
  UNIQUE KEY `info_id` (`info_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `professions`
--
-- Creation: May 31, 2012 at 10:23 AM
-- Last update: May 31, 2012 at 10:40 AM
--

DROP TABLE IF EXISTS `professions`;
CREATE TABLE IF NOT EXISTS `professions` (
  `prof_id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `profession` varchar(16) NOT NULL,
  PRIMARY KEY (`prof_id`),
  UNIQUE KEY `prof_id` (`prof_id`),
  UNIQUE KEY `profession` (`profession`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `professions`
--

INSERT INTO `professions` (`prof_id`, `profession`) VALUES(1, 'Alchemy');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(2, 'Blacksmithing');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(3, 'Enchanting');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(4, 'Engineering');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(5, 'Herbalism');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(6, 'Inscription');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(7, 'Jewelcrafting');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(8, 'Leatherworking');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(9, 'Mining');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(10, 'Skinning');
INSERT INTO `professions` (`prof_id`, `profession`) VALUES(11, 'Tailoring');

-- --------------------------------------------------------

--
-- Table structure for table `ranks`
--
-- Creation: May 31, 2012 at 10:51 AM
-- Last update: May 31, 2012 at 10:53 AM
--

DROP TABLE IF EXISTS `ranks`;
CREATE TABLE IF NOT EXISTS `ranks` (
  `rank_id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `rank` varchar(10) NOT NULL,
  PRIMARY KEY (`rank_id`),
  UNIQUE KEY `rank_id` (`rank_id`),
  UNIQUE KEY `rank` (`rank`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `ranks`
--

INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(1, 'Initiate');
INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(2, 'Alternate');
INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(3, 'Member');
INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(4, 'Raider');
INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(5, 'Veteran');
INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(6, 'Officer');
INSERT INTO `ranks` (`rank_id`, `rank`) VALUES(7, 'GMaster');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--
-- Creation: May 31, 2012 at 10:29 AM
-- Last update: May 31, 2012 at 10:33 AM
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `role` varchar(4) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_id` (`role_id`),
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role`) VALUES(1, 'DPS');
INSERT INTO `roles` (`role_id`, `role`) VALUES(2, 'Heal');
INSERT INTO `roles` (`role_id`, `role`) VALUES(3, 'Tank');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
